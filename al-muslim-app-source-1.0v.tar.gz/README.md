# al-muslim for Linux

KDE Plasma widget + standalone Qt desktop app.

## Version

`1.0v`

## Widget (Plasma)

Package widget tarball:

```bash
./scripts/package_widget.sh
```

Install widget directly:

```bash
./scripts/install_widget.sh
```

## Desktop App (Qt)

Build app:

```bash
./scripts/build_app.sh
```

Run app:

```bash
./scripts/run_app.sh
```

Install app locally:

```bash
./scripts/install_app.sh
```

## Output Artifacts

- Widget archive: `dist/al-muslim-widget-<version>.plasmoid.tar.gz`
- App binary: `build-app/al-muslim`
