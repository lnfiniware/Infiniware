#!/usr/bin/env bash
set -euo pipefail

missing=0

if ! command -v cmake >/dev/null 2>&1; then
    echo "Missing: cmake"
    missing=1
fi

if ! command -v c++ >/dev/null 2>&1; then
    echo "Missing: C++ compiler (g++)"
    missing=1
fi

if ! command -v pkg-config >/dev/null 2>&1; then
    echo "Missing: pkg-config"
    missing=1
fi

if ! pkg-config --exists Qt6Core Qt6Quick Qt6QuickControls2 Qt6Multimedia 2>/dev/null; then
    echo "Missing: Qt6 development packages (Core/Quick/QuickControls2/Multimedia)"
    missing=1
fi

if [[ "$missing" -eq 0 ]]; then
    echo "All required build dependencies are available."
    exit 0
fi

cat <<'HINT'

Install hints:

Fedora:
  sudo dnf install -y cmake gcc-c++ qt6-qtbase-devel qt6-qtdeclarative-devel qt6-qtmultimedia-devel pkgconf-pkg-config

Ubuntu/Debian:
  sudo apt update
  sudo apt install -y cmake g++ pkg-config qt6-base-dev qt6-declarative-dev qt6-multimedia-dev

Arch:
  sudo pacman -S --needed cmake gcc pkgconf qt6-base qt6-declarative qt6-multimedia
HINT

exit 1
