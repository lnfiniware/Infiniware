#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${1:-$ROOT_DIR/build-app}"
shift $(( $# > 0 ? 1 : 0 )) || true

"$ROOT_DIR/scripts/build_app.sh" "$BUILD_DIR"

APP_BIN="$BUILD_DIR/al-muslim"
if [[ ! -x "$APP_BIN" ]]; then
    echo "Error: built binary not found at $APP_BIN" >&2
    exit 1
fi

exec "$APP_BIN" "$@"
