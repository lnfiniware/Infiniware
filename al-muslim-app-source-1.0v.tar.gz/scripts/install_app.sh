#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${1:-$ROOT_DIR/build-app}"
PREFIX="${PREFIX:-$HOME/.local}"

"$ROOT_DIR/scripts/build_app.sh" "$BUILD_DIR"
cmake --install "$BUILD_DIR" --prefix "$PREFIX"

echo "App installed to: $PREFIX"
