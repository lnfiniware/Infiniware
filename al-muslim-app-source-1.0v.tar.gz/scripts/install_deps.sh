#!/usr/bin/env bash
set -euo pipefail

if [[ "$EUID" -ne 0 ]]; then
    echo "Please run as root (sudo) to install dependencies."
    exit 1
fi

if command -v dnf >/dev/null 2>&1; then
    dnf install -y cmake gcc-c++ qt6-qtbase-devel qt6-qtdeclarative-devel qt6-qtmultimedia-devel pkgconf-pkg-config
elif command -v apt >/dev/null 2>&1; then
    apt update
    apt install -y cmake g++ pkg-config qt6-base-dev qt6-declarative-dev qt6-multimedia-dev
elif command -v pacman >/dev/null 2>&1; then
    pacman -S --needed --noconfirm cmake gcc pkgconf qt6-base qt6-declarative qt6-multimedia
else
    echo "Unsupported package manager. Install Qt6 dev deps manually."
    exit 1
fi

echo "Dependencies installed."
