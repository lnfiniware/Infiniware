#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${1:-$ROOT_DIR/build-app}"
BUILD_TYPE="${BUILD_TYPE:-Release}"

if ! command -v cmake >/dev/null 2>&1; then
    echo "Error: cmake is required but not found in PATH." >&2
    exit 1
fi

if ! command -v pkg-config >/dev/null 2>&1 || ! pkg-config --exists Qt6Core Qt6Quick Qt6QuickControls2 Qt6Multimedia 2>/dev/null; then
    echo "Error: Qt6 development packages are missing." >&2
    echo "Run: $ROOT_DIR/scripts/check_deps.sh" >&2
    echo "Then install deps with: sudo $ROOT_DIR/scripts/install_deps.sh" >&2
    exit 1
fi

cmake -S "$ROOT_DIR/app" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE="$BUILD_TYPE"
cmake --build "$BUILD_DIR" -j"$(nproc)"

echo "Build complete: $BUILD_DIR/al-muslim"
