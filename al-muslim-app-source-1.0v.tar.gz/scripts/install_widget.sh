#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="$ROOT_DIR/dist"

"$ROOT_DIR/scripts/package_widget.sh" "$DIST_DIR"
ARCHIVE="$(ls -1t "$DIST_DIR"/al-muslim-widget-*.plasmoid.tar.gz | head -n1)"

if command -v kpackagetool6 >/dev/null 2>&1; then
    kpackagetool6 --type Plasma/Applet --install "$ARCHIVE"
elif command -v kpackagetool5 >/dev/null 2>&1; then
    kpackagetool5 --type Plasma/Applet --install "$ARCHIVE"
elif command -v plasmapkg2 >/dev/null 2>&1; then
    plasmapkg2 -i "$ARCHIVE"
else
    echo "No Plasma package installer found (kpackagetool6/kpackagetool5/plasmapkg2)."
    echo "Use the archive manually: $ARCHIVE"
    exit 1
fi

echo "Widget installed from: $ARCHIVE"
