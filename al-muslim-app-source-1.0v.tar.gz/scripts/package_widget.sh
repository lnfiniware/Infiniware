#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="${1:-$ROOT_DIR/dist}"

mkdir -p "$DIST_DIR"

if command -v jq >/dev/null 2>&1; then
    VERSION="$(jq -r '.KPlugin.Version // "1.0v"' "$ROOT_DIR/metadata.json")"
else
    VERSION="$(grep -E '"Version"' "$ROOT_DIR/metadata.json" | head -n1 | sed -E 's/.*"Version"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/' || true)"
    VERSION="${VERSION:-1.0v}"
fi

ARCHIVE="$DIST_DIR/al-muslim-widget-${VERSION}.plasmoid.tar.gz"

# Package only widget-relevant files.
tar -czf "$ARCHIVE" -C "$ROOT_DIR" metadata.json contents license

echo "Widget package created: $ARCHIVE"
