#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="$ROOT_DIR/dist"
mkdir -p "$DIST_DIR"

"$ROOT_DIR/scripts/package_widget.sh" "$DIST_DIR"

VERSION="$(jq -r '.KPlugin.Version // "1.0v"' "$ROOT_DIR/metadata.json" 2>/dev/null || echo "1.0v")"
APP_SRC_ARCHIVE="$DIST_DIR/al-muslim-app-source-${VERSION}.tar.gz"

tar -czf "$APP_SRC_ARCHIVE" -C "$ROOT_DIR" app CMakeLists.txt README.md license scripts

echo "Release artifacts:"
ls -lh "$DIST_DIR"/al-muslim-widget-*.plasmoid.tar.gz "$APP_SRC_ARCHIVE"
