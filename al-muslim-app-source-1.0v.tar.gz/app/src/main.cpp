#include <QCoreApplication>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QDebug>
#include <QQmlError>
#include <QList>
#include <cstdio>

int main(int argc, char *argv[])
{
    QCoreApplication::setOrganizationName(QStringLiteral("lnfiniware"));
    QCoreApplication::setOrganizationDomain(QStringLiteral("infiniware.bid"));
    QCoreApplication::setApplicationName(QStringLiteral("al-muslim"));
    QCoreApplication::setApplicationVersion(QStringLiteral("1.0v"));

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty(QStringLiteral("AL_MUSLIM_VERSION"), QStringLiteral("1.0v"));
    engine.rootContext()->setContextProperty(QStringLiteral("AL_MUSLIM_AUTHOR"), QStringLiteral("Zyad Mohamed"));
    engine.rootContext()->setContextProperty(QStringLiteral("AL_MUSLIM_EMAIL"), QStringLiteral("fut0r@infiniware.bid"));

    QList<QQmlError> capturedWarnings;
    QObject::connect(&engine, &QQmlEngine::warnings, &app,
                     [&capturedWarnings](const QList<QQmlError> &warnings) {
                         capturedWarnings = warnings;
                     });

    auto dumpWarnings = [&capturedWarnings]() {
        for (const auto &warning : capturedWarnings) {
            std::fprintf(stderr, "%s\n", qPrintable(warning.toString()));
        }
    };

    const QUrl qrcModulePath(QStringLiteral("qrc:/qt/qml/AlMuslim/qml/Main.qml"));
    engine.load(qrcModulePath);
    if (engine.rootObjects().isEmpty()) {
        dumpWarnings();
        const QUrl legacyQrcPath(QStringLiteral("qrc:/qt/qml/AlMuslim/Main.qml"));
        engine.load(legacyQrcPath);
    }
    if (engine.rootObjects().isEmpty()) {
        dumpWarnings();
        qWarning() << "Failed to load AlMuslim Main.qml from module or qrc paths.";
        return -1;
    }

    return app.exec();
}
