import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property string prayerName: ""
    property string prayerTime: "--:--"
    property bool active: false

    radius: 10
    color: active ? "#2B7A78" : "#13232F"
    border.width: active ? 1 : 0
    border.color: "#58B7B3"

    implicitHeight: 46
    Layout.fillWidth: true

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 12
        spacing: 10

        Label {
            text: root.prayerName
            color: "#EAF7F6"
            font.bold: true
            Layout.alignment: Qt.AlignVCenter
        }

        Item {
            Layout.fillWidth: true
        }

        Label {
            text: root.prayerTime
            color: "#EAF7F6"
            Layout.alignment: Qt.AlignVCenter
        }
    }
}
