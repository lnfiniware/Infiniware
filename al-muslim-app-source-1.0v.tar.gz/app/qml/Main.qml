import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import QtMultimedia

ApplicationWindow {
    id: root

    width: 1080
    height: 760
    minimumWidth: 900
    minimumHeight: 620
    visible: true
    title: isArabicUi ? "المسلم للينكس" : "al-muslim for Linux"

    property string appVersion: (typeof AL_MUSLIM_VERSION !== "undefined") ? AL_MUSLIM_VERSION : "1.0v"
    property string authorName: (typeof AL_MUSLIM_AUTHOR !== "undefined") ? AL_MUSLIM_AUTHOR : "Zyad Mohamed"
    property string authorEmail: (typeof AL_MUSLIM_EMAIL !== "undefined") ? AL_MUSLIM_EMAIL : "fut0r@infiniware.bid"

    property var methodMap: [0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 21]
    property var methodNames: [
        "Shia Ithna-Ansari", "University of Islamic Sciences, Karachi", "Islamic Society of North America",
        "Muslim World League", "Umm Al-Qura University, Makkah", "Egyptian General Authority of Survey",
        "Institute of Geophysics, University of Tehran", "Gulf Region", "Kuwait", "Qatar",
        "MUIS, Singapore", "Union Organization islamic de France", "Diyanet, Turkey",
        "Spiritual Administration of Muslims of Russia", "Morocco"
    ]

    property var reciterIdentifiers: [
        "ar.minshawi", "ar.alafasy", "ar.husary", "ar.abdurrahmaansudais",
        "ar.mahermuaiqly", "ar.shaatree", "ar.abdullahbasfar", "ar.abdulbasitmurattal",
        "ar.hudhaify", "ar.muhammadjibreel", "ar.husarymujawwad", "ar.minshawimujawwad", "ar.ahmedajamy"
    ]

    property var reciterNamesEn: [
        "Minshawi (Murattal)", "Alafasy", "Husary (Murattal)", "Abdurrahmaan As-Sudais", "Maher Al Muaiqly",
        "Abu Bakr Ash-Shaatree", "Abdullah Basfar", "Abdulbasit (Murattal)", "Hudhaify", "Muhammad Jibreel",
        "Husary (Mujawwad)", "Minshawi (Mujawwad)", "Ahmed ibn Ali al-Ajamy"
    ]

    property var reciterNamesAr: [
        "المنشاوي (مرتل)", "العفاسي", "الحصري (مرتل)", "عبد الرحمن السديس", "ماهر المعيقلي",
        "أبو بكر الشاطري", "عبد الله بصفر", "عبد الباسط (مرتل)", "الحذيفي", "محمد جبريل",
        "الحصري (مجود)", "المنشاوي (مجود)", "أحمد بن علي العجمي"
    ]

    property var surahData: [
        ["Al-Fatiha", "الفاتحة", 7], ["Al-Baqarah", "البقرة", 286], ["Al-Imran", "آل عمران", 200], ["An-Nisa", "النساء", 176],
        ["Al-Ma'idah", "المائدة", 120], ["Al-An'am", "الأنعام", 165], ["Al-A'raf", "الأعراف", 206], ["Al-Anfal", "الأنفال", 75],
        ["At-Tawbah", "التوبة", 129], ["Yunus", "يونس", 109], ["Hud", "هود", 123], ["Yusuf", "يوسف", 111],
        ["Ar-Ra'd", "الرعد", 43], ["Ibrahim", "إبراهيم", 52], ["Al-Hijr", "الحجر", 99], ["An-Nahl", "النحل", 128],
        ["Al-Isra", "الإسراء", 111], ["Al-Kahf", "الكهف", 110], ["Maryam", "مريم", 98], ["Ta-Ha", "طه", 135],
        ["Al-Anbiya", "الأنبياء", 112], ["Al-Hajj", "الحج", 78], ["Al-Mu'minun", "المؤمنون", 118], ["An-Nur", "النور", 64],
        ["Al-Furqan", "الفرقان", 77], ["Ash-Shu'ara", "الشعراء", 227], ["An-Naml", "النمل", 93], ["Al-Qasas", "القصص", 88],
        ["Al-Ankabut", "العنكبوت", 69], ["Ar-Rum", "الروم", 60], ["Luqman", "لقمان", 34], ["As-Sajdah", "السجدة", 30],
        ["Al-Ahzab", "الأحزاب", 73], ["Saba", "سبأ", 54], ["Fatir", "فاطر", 45], ["Ya-Sin", "يس", 83],
        ["As-Saffat", "الصافات", 182], ["Sad", "ص", 88], ["Az-Zumar", "الزمر", 75], ["Ghafir", "غافر", 85],
        ["Fussilat", "فصلت", 54], ["Ash-Shura", "الشورى", 53], ["Az-Zukhruf", "الزخرف", 89], ["Ad-Dukhan", "الدخان", 59],
        ["Al-Jathiyah", "الجاثية", 37], ["Al-Ahqaf", "الأحقاف", 35], ["Muhammad", "محمد", 38], ["Al-Fath", "الفتح", 29],
        ["Al-Hujurat", "الحجرات", 18], ["Qaf", "ق", 45], ["Ad-Dhariyat", "الذاريات", 60], ["At-Tur", "الطور", 49],
        ["An-Najm", "النجم", 62], ["Al-Qamar", "القمر", 55], ["Ar-Rahman", "الرحمن", 78], ["Al-Waqi'ah", "الواقعة", 96],
        ["Al-Hadid", "الحديد", 29], ["Al-Mujadila", "المجادلة", 22], ["Al-Hashr", "الحشر", 24], ["Al-Mumtahanah", "الممتحنة", 13],
        ["As-Saff", "الصف", 14], ["Al-Jumu'ah", "الجمعة", 11], ["Al-Munafiqun", "المنافقون", 11], ["At-Taghabun", "التغابن", 18],
        ["At-Talaq", "الطلاق", 12], ["At-Tahrim", "التحريم", 12], ["Al-Mulk", "الملك", 30], ["Al-Qalam", "القلم", 52],
        ["Al-Haqqah", "الحاقة", 52], ["Al-Ma'arij", "المعارج", 44], ["Nuh", "نوح", 28], ["Al-Jinn", "الجن", 28],
        ["Al-Muzzammil", "المزمل", 20], ["Al-Muddaththir", "المدثر", 56], ["Al-Qiyamah", "القيامة", 40], ["Al-Insan", "الإنسان", 31],
        ["Al-Mursalat", "المرسلات", 50], ["An-Naba", "النبأ", 40], ["An-Nazi'at", "النازعات", 46], ["Abasa", "عبس", 42],
        ["At-Takwir", "التكوير", 29], ["Al-Infitar", "الانفطار", 19], ["Al-Mutaffifin", "المطففين", 36], ["Al-Inshiqaq", "الانشقاق", 25],
        ["Al-Buruj", "البروج", 22], ["At-Tariq", "الطارق", 17], ["Al-A'la", "الأعلى", 19], ["Al-Ghashiyah", "الغاشية", 26],
        ["Al-Fajr", "الفجر", 30], ["Al-Balad", "البلد", 20], ["Ash-Shams", "الشمس", 15], ["Al-Layl", "الليل", 21],
        ["Ad-Duha", "الضحى", 11], ["Ash-Sharh", "الشرح", 8], ["At-Tin", "التين", 8], ["Al-Alaq", "العلق", 19],
        ["Al-Qadr", "القدر", 5], ["Al-Bayyinah", "البينة", 8], ["Az-Zalzalah", "الزلزلة", 8], ["Al-Adiyat", "العاديات", 11],
        ["Al-Qari'ah", "القارعة", 11], ["At-Takathur", "التكاثر", 8], ["Al-Asr", "العصر", 3], ["Al-Humazah", "الهمزة", 9],
        ["Al-Fil", "الفيل", 5], ["Quraysh", "قريش", 4], ["Al-Ma'un", "الماعون", 7], ["Al-Kawthar", "الكوثر", 3],
        ["Al-Kafirun", "الكافرون", 6], ["An-Nasr", "النصر", 3], ["Al-Masad", "المسد", 5], ["Al-Ikhlas", "الإخلاص", 4],
        ["Al-Falaq", "الفلق", 5], ["An-Nas", "الناس", 6]
    ]

    Settings {
        id: settings
        category: "AlMuslimApp"

        property int languageMode: 0
        property string city: "Makkah"
        property string country: "Saudi Arabia"
        property bool useCoordinates: false
        property string latitude: ""
        property string longitude: ""
        property int method: 4
        property int school: 0
        property bool hourFormat: true
        property int hijriOffset: 0

        property int fajrOffsetMinutes: 0
        property int sunriseOffsetMinutes: 0
        property int dhuhrOffsetMinutes: 0
        property int asrOffsetMinutes: 0
        property int maghribOffsetMinutes: 0
        property int ishaOffsetMinutes: 0

        property bool notifications: true
        property int adhanPlaybackMode: 3
        property real adhanVolume: 0.7
        property string adhanAudioPath: ""
        property bool playAdhanForFajr: true
        property bool playAdhanForDhuhr: true
        property bool playAdhanForAsr: true
        property bool playAdhanForMaghrib: true
        property bool playAdhanForIsha: true

        property int quranReciterIndex: 0
        property real quranVolume: 0.7
    }

    readonly property bool systemLanguageIsArabic: Qt.locale().name.toLowerCase().indexOf("ar") === 0
    property bool isArabicUi: settings.languageMode === 2 || (settings.languageMode === 0 && systemLanguageIsArabic)

    property var rawTimes: ({})
    property var displayPrayerTimes: ({})
    property string hijriDateDisplay: "--"
    property string specialIslamicDateMessage: ""
    property string nextPrayerName: ""
    property string nextPrayerTime: ""
    property string timeUntilNextPrayer: ""
    property date nextPrayerDateTime: new Date(0)
    property string activePrayer: ""
    property bool activePrayerInitialized: false
    property string statusMessage: ""
    property string lastUpdateText: "--"

    property string dailyVerseArabic: "..."
    property string dailyVerseTranslation: ""
    property string dailyVerseReference: ""
    property int currentSurahNumber: 1
    property int currentAyahNumber: 1

    property bool isAdhanPlaying: false
    property bool resumeVerseAfterAdhanFlag: false
    property int verseResumePosition: 0

    function t(en, ar) {
        return isArabicUi ? ar : en
    }

    function prayerName(prayerKey) {
        const arabicPrayers = {
            "Fajr": "الفجر",
            "Sunrise": "الشروق",
            "Dhuhr": "الظهر",
            "Asr": "العصر",
            "Maghrib": "المغرب",
            "Isha": "العشاء"
        }
        return isArabicUi ? (arabicPrayers[prayerKey] || prayerKey) : prayerKey
    }

    function getFormattedDate(dateObj) {
        const day = String(dateObj.getDate()).padStart(2, "0")
        const month = String(dateObj.getMonth() + 1).padStart(2, "0")
        const year = dateObj.getFullYear()
        return day + "-" + month + "-" + year
    }

    function parseTime(timeString) {
        if (!timeString || timeString === "--:--") {
            return new Date(0)
        }

        const parts = timeString.split(":")
        if (parts.length < 2) {
            return new Date(0)
        }

        const dateObj = new Date()
        dateObj.setHours(parseInt(parts[0], 10))
        dateObj.setMinutes(parseInt(parts[1], 10))
        dateObj.setSeconds(0)
        dateObj.setMilliseconds(0)
        return dateObj
    }

    function to12HourTime(timeString) {
        if (!timeString || timeString === "--:--") {
            return "--:--"
        }

        if (!settings.hourFormat) {
            return timeString
        }

        const parts = timeString.split(":")
        let hours = parseInt(parts[0], 10)
        const minutes = parseInt(parts[1], 10)
        const period = hours >= 12 ? t("PM", "م") : t("AM", "ص")
        hours = hours % 12 || 12
        return String(hours) + ":" + String(minutes).padStart(2, "0") + " " + period
    }

    function applyOffsetToTime(timeString, offsetMinutes) {
        if (!timeString || timeString === "--:--" || offsetMinutes === 0) {
            return timeString
        }

        const parts = timeString.split(":")
        let totalMinutes = (parseInt(parts[0], 10) * 60) + parseInt(parts[1], 10) + offsetMinutes
        totalMinutes = ((totalMinutes % 1440) + 1440) % 1440
        const hours = Math.floor(totalMinutes / 60)
        const minutes = totalMinutes % 60
        return String(hours).padStart(2, "0") + ":" + String(minutes).padStart(2, "0")
    }

    function getPrayerOffset(prayerKey) {
        switch (prayerKey) {
        case "Fajr": return settings.fajrOffsetMinutes
        case "Sunrise": return settings.sunriseOffsetMinutes
        case "Dhuhr": return settings.dhuhrOffsetMinutes
        case "Asr": return settings.asrOffsetMinutes
        case "Maghrib": return settings.maghribOffsetMinutes
        case "Isha": return settings.ishaOffsetMinutes
        default: return 0
        }
    }

    function processRawTimesAndApplyOffsets() {
        if (!rawTimes || !rawTimes.Fajr) {
            displayPrayerTimes = {
                Fajr: "--:--",
                Sunrise: "--:--",
                Dhuhr: "--:--",
                Asr: "--:--",
                Maghrib: "--:--",
                Isha: "--:--",
                apiGregorianDate: getFormattedDate(new Date())
            }
            return
        }

        const keys = ["Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"]
        const nextData = {}

        for (let i = 0; i < keys.length; ++i) {
            const key = keys[i]
            nextData[key] = applyOffsetToTime(rawTimes[key], getPrayerOffset(key))
        }

        nextData.apiGregorianDate = rawTimes.apiGregorianDate
        displayPrayerTimes = nextData
        highlightActivePrayer()
        calculateNextPrayer()
    }

    function calculateNextPrayer() {
        const prayerKeys = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"]
        const now = new Date()
        const currentTime = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0")

        let nextKey = ""
        let nextTime = ""

        for (let i = 0; i < prayerKeys.length; ++i) {
            const key = prayerKeys[i]
            const value = displayPrayerTimes[key]
            if (value && value !== "--:--" && value > currentTime) {
                nextKey = key
                nextTime = value
                break
            }
        }

        if (nextKey === "" && displayPrayerTimes.Fajr && displayPrayerTimes.Fajr !== "--:--") {
            nextKey = "Fajr"
            nextTime = displayPrayerTimes.Fajr
        }

        if (nextKey === "") {
            nextPrayerName = t("N/A", "غير متاح")
            nextPrayerTime = ""
            timeUntilNextPrayer = ""
            return
        }

        nextPrayerName = prayerName(nextKey)
        nextPrayerTime = to12HourTime(nextTime)

        nextPrayerDateTime = parseTime(nextTime)
        if (nextKey === "Fajr" && now > nextPrayerDateTime) {
            nextPrayerDateTime.setDate(nextPrayerDateTime.getDate() + 1)
        }

        updateCountdown()
    }

    function updateCountdown() {
        if (!nextPrayerDateTime || nextPrayerDateTime.getTime() <= 0) {
            timeUntilNextPrayer = ""
            return
        }

        const now = new Date()
        const diffMs = nextPrayerDateTime.getTime() - now.getTime()

        if (diffMs <= 0) {
            timeUntilNextPrayer = t("Prayer time!", "حان وقت الصلاة")
            fetchTimes()
            return
        }

        const totalMinutes = Math.floor(diffMs / (1000 * 60))
        const hours = Math.floor(totalMinutes / 60)
        const minutes = totalMinutes % 60
        timeUntilNextPrayer = String(hours).padStart(2, "0") + ":" + String(minutes).padStart(2, "0")
    }

    function updateSpecialIslamicDateMessage(day, month) {
        let message = ""

        if (month === 9) {
            message = t("Month of Ramadan", "شهر رمضان")
        } else if (month === 10 && day === 1) {
            message = t("Eid al-Fitr", "عيد الفطر")
        } else if (month === 12) {
            if (day >= 1 && day <= 10) {
                message = t("First 10 Days of Dhu al-Hijjah", "العشر الأوائل من ذي الحجة")
                if (day === 9) {
                    message = t("Day of Arafah", "يوم عرفة")
                }
                if (day === 10) {
                    message = t("Eid al-Adha", "عيد الأضحى")
                }
            } else if (day >= 11 && day <= 13) {
                message = t("Days of Tashreeq", "أيام التشريق")
            }
        } else if (month === 1 && day === 1) {
            message = t("Islamic New Year", "رأس السنة الهجرية")
        } else if (month === 1 && day === 10) {
            message = t("Day of Ashura", "يوم عاشوراء")
        }

        if (message === "") {
            if (day === 13 || day === 14 || day === 15) {
                message = t("Ayyam al-Bid", "الأيام البيض")
            } else if (day === 12) {
                message = t("White Days begin tomorrow", "غداً تبدأ الأيام البيض")
            } else if (day === 11) {
                message = t("2 days until White Days", "باقي يومان على الأيام البيض")
            }
        }

        specialIslamicDateMessage = message
    }

    function setHijriData(hijriData) {
        if (!hijriData || !hijriData.month) {
            hijriDateDisplay = t("Date unavailable", "التاريخ غير متاح")
            specialIslamicDateMessage = ""
            return
        }

        let day = parseInt(hijriData.day, 10)
        let month = parseInt(hijriData.month.number, 10)
        let year = parseInt(hijriData.year, 10)

        day += settings.hijriOffset
        if (day > 30) {
            day -= 30
            month += 1
            if (month > 12) {
                month = 1
                year += 1
            }
        } else if (day < 1) {
            day += 30
            month -= 1
            if (month < 1) {
                month = 12
                year -= 1
            }
        }

        const arMonths = ["محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"]
        const enMonths = ["Muharram", "Safar", "Rabi Al-Awwal", "Rabi Al-Thani", "Jumada Al-Awwal", "Jumada Al-Thani", "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu Al-Qi'dah", "Dhu Al-Hijjah"]

        const monthName = isArabicUi ? arMonths[Math.max(0, month - 1)] : enMonths[Math.max(0, month - 1)]
        hijriDateDisplay = String(day) + " " + monthName + " " + String(year)
        updateSpecialIslamicDateMessage(day, month)
    }

    function pushStatus(message) {
        statusMessage = message
        statusTimer.restart()
    }

    function shouldPlayAdhanForPrayer(prayerNameKey) {
        switch (prayerNameKey) {
        case "Fajr": return settings.playAdhanForFajr
        case "Dhuhr": return settings.playAdhanForDhuhr
        case "Asr": return settings.playAdhanForAsr
        case "Maghrib": return settings.playAdhanForMaghrib
        case "Isha": return settings.playAdhanForIsha
        default: return false
        }
    }

    function adhanSourceUrl() {
        if (settings.adhanAudioPath && settings.adhanAudioPath.length > 0) {
            if (settings.adhanAudioPath.startsWith("file://") || settings.adhanAudioPath.startsWith("http")) {
                return settings.adhanAudioPath
            }
            return "file://" + settings.adhanAudioPath
        }
        return "qrc:/al-muslim/Adhan.mp3"
    }

    function playAdhanAudio(prayerNameKey) {
        if (settings.adhanPlaybackMode === 0) {
            return
        }

        if (!shouldPlayAdhanForPrayer(prayerNameKey)) {
            return
        }

        resumeVerseAfterAdhanFlag = versePlayer.playbackState === MediaPlayer.PlayingState
        verseResumePosition = versePlayer.position

        if (resumeVerseAfterAdhanFlag) {
            versePlayer.pause()
        }

        adhanPlayer.source = adhanSourceUrl()
        isAdhanPlaying = true
        adhanPlayer.play()

        if (settings.adhanPlaybackMode === 2) {
            adhanStopTimer.interval = 40000
            adhanStopTimer.restart()
        } else if (settings.adhanPlaybackMode === 3) {
            adhanStopTimer.interval = 17000
            adhanStopTimer.restart()
        } else {
            adhanStopTimer.stop()
        }
    }

    function highlightActivePrayer() {
        const order = ["Isha", "Maghrib", "Asr", "Dhuhr", "Sunrise", "Fajr"]
        const now = new Date()

        let current = ""
        for (let i = 0; i < order.length; ++i) {
            const key = order[i]
            const value = displayPrayerTimes[key]
            if (value && value !== "--:--" && now >= parseTime(value)) {
                current = key
                break
            }
        }

        if (current === "" && displayPrayerTimes.Fajr && displayPrayerTimes.Fajr !== "--:--") {
            current = "Isha"
        }

        if (activePrayer !== current) {
            const previousPrayer = activePrayer
            activePrayer = current

            if (activePrayerInitialized && previousPrayer !== "" && activePrayer !== "" && activePrayer !== "Sunrise") {
                pushStatus(t("It is now " + prayerName(activePrayer), "الآن وقت " + prayerName(activePrayer)))
                if (settings.notifications) {
                    playAdhanAudio(activePrayer)
                }
            }

            activePrayerInitialized = true
        }
    }

    function fetchTimes() {
        const todayForApi = getFormattedDate(new Date())
        const methodIndex = (methodMap[settings.method] !== undefined) ? methodMap[settings.method] : 4

        let url = ""
        if (settings.useCoordinates && settings.latitude !== "" && settings.longitude !== "") {
            url = "https://api.aladhan.com/v1/timings/" + todayForApi
            url += "?latitude=" + encodeURIComponent(settings.latitude)
            url += "&longitude=" + encodeURIComponent(settings.longitude)
            url += "&method=" + methodIndex
            url += "&school=" + settings.school
        } else {
            url = "https://api.aladhan.com/v1/timingsByCity/" + todayForApi
            url += "?city=" + encodeURIComponent(settings.city)
            url += "&country=" + encodeURIComponent(settings.country)
            url += "&method=" + methodIndex
            url += "&school=" + settings.school
        }

        const xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== 4) {
                return
            }

            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText).data
                    rawTimes = {
                        Fajr: (response.timings.Fajr || "--:--").split(" ")[0],
                        Sunrise: (response.timings.Sunrise || "--:--").split(" ")[0],
                        Dhuhr: (response.timings.Dhuhr || "--:--").split(" ")[0],
                        Asr: (response.timings.Asr || "--:--").split(" ")[0],
                        Maghrib: (response.timings.Maghrib || "--:--").split(" ")[0],
                        Isha: (response.timings.Isha || "--:--").split(" ")[0],
                        apiGregorianDate: response.date.gregorian.date
                    }
                    processRawTimesAndApplyOffsets()
                    setHijriData(response.date.hijri)
                    lastUpdateText = new Date().toLocaleTimeString()
                    pushStatus(t("Prayer times updated", "تم تحديث مواقيت الصلاة"))
                } catch (error) {
                    pushStatus(t("Failed to parse prayer data", "تعذر قراءة بيانات الصلاة"))
                }
            } else {
                pushStatus(t("Failed to fetch prayer times", "فشل جلب مواقيت الصلاة"))
            }
        }

        xhr.open("GET", url, true)
        xhr.send()
    }

    function fetchDailyVerse() {
        const randomAyahNumber = Math.floor(Math.random() * 6236) + 1
        const reciterId = reciterIdentifiers[Math.max(0, Math.min(reciterIdentifiers.length - 1, settings.quranReciterIndex))]
        const url = "https://api.alquran.cloud/v1/ayah/" + randomAyahNumber + "/editions/quran-uthmani,en.sahih," + reciterId

        const xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== 4) {
                return
            }

            if (xhr.status === 200) {
                try {
                    const data = JSON.parse(xhr.responseText).data
                    const arabicData = data.find(function(ed) { return ed.edition.identifier === "quran-uthmani" })
                    const translationData = data.find(function(ed) { return ed.edition.identifier === "en.sahih" })

                    if (arabicData) {
                        dailyVerseArabic = arabicData.text
                        dailyVerseTranslation = translationData ? translationData.text : ""
                        dailyVerseReference = t("Surah ", "سورة ") + arabicData.surah.englishName + " (" + arabicData.surah.number + ":" + arabicData.numberInSurah + ")"
                        currentSurahNumber = arabicData.surah.number
                        currentAyahNumber = arabicData.numberInSurah
                    }
                } catch (error) {
                    pushStatus(t("Failed to parse verse", "تعذر قراءة الآية"))
                }
            } else {
                pushStatus(t("Verse API unavailable", "واجهة الآيات غير متاحة"))
            }
        }

        xhr.open("GET", url, true)
        xhr.send()
    }

    function playSpecificVerse(surahNum, ayahNum) {
        const reciterId = reciterIdentifiers[Math.max(0, Math.min(reciterIdentifiers.length - 1, settings.quranReciterIndex))]
        const url = "https://api.alquran.cloud/v1/ayah/" + surahNum + ":" + ayahNum + "/editions/quran-uthmani,en.sahih," + reciterId

        const xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== 4) {
                return
            }

            if (xhr.status === 200) {
                try {
                    const data = JSON.parse(xhr.responseText).data
                    const arabicData = data.find(function(ed) { return ed.edition.identifier === "quran-uthmani" })
                    const translationData = data.find(function(ed) { return ed.edition.identifier === "en.sahih" })
                    const audioData = data.find(function(ed) { return ed.edition.identifier === reciterId })

                    if (arabicData && audioData && audioData.audio) {
                        dailyVerseArabic = arabicData.text
                        dailyVerseTranslation = translationData ? translationData.text : ""
                        dailyVerseReference = t("Surah ", "سورة ") + arabicData.surah.englishName + " (" + arabicData.surah.number + ":" + arabicData.numberInSurah + ")"
                        currentSurahNumber = arabicData.surah.number
                        currentAyahNumber = arabicData.numberInSurah

                        versePlayer.source = audioData.audio
                        versePlayer.play()
                    }
                } catch (error) {
                    pushStatus(t("Failed to play verse", "تعذر تشغيل الآية"))
                }
            } else {
                pushStatus(t("Failed to fetch verse audio", "فشل جلب صوت الآية"))
            }
        }

        xhr.open("GET", url, true)
        xhr.send()
    }

    Timer {
        id: statusTimer
        interval: 3200
        repeat: false
        onTriggered: statusMessage = ""
    }

    Timer {
        id: refreshTimer
        interval: 30000
        repeat: true
        running: true
        onTriggered: {
            if (!displayPrayerTimes.apiGregorianDate || displayPrayerTimes.apiGregorianDate !== getFormattedDate(new Date())) {
                fetchTimes()
                fetchDailyVerse()
            } else {
                highlightActivePrayer()
                updateCountdown()
            }
        }
    }

    Timer {
        id: countdownTimer
        interval: 15000
        repeat: true
        running: true
        onTriggered: updateCountdown()
    }

    Timer {
        id: adhanStopTimer
        interval: 17000
        repeat: false
        onTriggered: {
            adhanPlayer.stop()
        }
    }

    AudioOutput {
        id: verseOutput
        volume: settings.quranVolume
    }

    AudioOutput {
        id: adhanOutput
        volume: settings.adhanVolume
    }

    MediaPlayer {
        id: versePlayer
        audioOutput: verseOutput
    }

    MediaPlayer {
        id: adhanPlayer
        audioOutput: adhanOutput
        onPlaybackStateChanged: {
            if (playbackState === MediaPlayer.StoppedState && isAdhanPlaying) {
                isAdhanPlaying = false
                adhanStopTimer.stop()
                if (resumeVerseAfterAdhanFlag) {
                    versePlayer.position = verseResumePosition
                    versePlayer.play()
                }
                resumeVerseAfterAdhanFlag = false
            }
        }
    }

    Component.onCompleted: {
        fetchTimes()
        fetchDailyVerse()
    }

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#0F1D2A" }
            GradientStop { position: 1.0; color: "#08131D" }
        }
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        ToolBar {
            Layout.fillWidth: true
            background: Rectangle { color: "#0E202F"; opacity: 0.95 }

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 10
                anchors.rightMargin: 10

                Label {
                    text: root.title + "  " + appVersion
                    color: "#EAF7F6"
                    font.bold: true
                    font.pixelSize: 16
                }

                Item { Layout.fillWidth: true }

                Button {
                    text: t("Refresh", "تحديث")
                    onClicked: {
                        fetchTimes()
                        fetchDailyVerse()
                    }
                }

                Button {
                    text: t("Stop Audio", "إيقاف الصوت")
                    onClicked: {
                        versePlayer.stop()
                        adhanPlayer.stop()
                        isAdhanPlaying = false
                    }
                }
            }
        }

        TabBar {
            id: pageTabs
            Layout.fillWidth: true

            TabButton { text: t("Dashboard", "الرئيسية") }
            TabButton { text: t("Quran", "القرآن") }
            TabButton { text: t("Settings", "الإعدادات") }
        }

        StackLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            currentIndex: pageTabs.currentIndex

            Item {
                ScrollView {
                    anchors.fill: parent
                    contentWidth: availableWidth

                    ColumnLayout {
                        width: parent.width - 28
                        x: 14
                        y: 14
                        spacing: 10

                        Rectangle {
                            Layout.fillWidth: true
                            radius: 12
                            color: "#13283A"
                            border.width: 1
                            border.color: "#1F3F55"

                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 6

                                Label {
                                    Layout.fillWidth: true
                                    text: "{صّلِ عَلۓِ مُحَمد ﷺ}"
                                    horizontalAlignment: Text.AlignHCenter
                                    color: "#F7F9E6"
                                    font.bold: true
                                    font.pixelSize: 20
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: hijriDateDisplay
                                    horizontalAlignment: Text.AlignHCenter
                                    color: "#EAF7F6"
                                    font.pixelSize: 18
                                    font.bold: true
                                }

                                Label {
                                    Layout.fillWidth: true
                                    visible: specialIslamicDateMessage !== ""
                                    text: specialIslamicDateMessage
                                    horizontalAlignment: Text.AlignHCenter
                                    color: "#E7DFA8"
                                    font.bold: true
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: t("Next prayer", "الصلاة القادمة") + ": " + nextPrayerName + " - " + nextPrayerTime
                                    color: "#C8EEF0"
                                }

                                Label {
                                    Layout.fillWidth: true
                                    visible: timeUntilNextPrayer !== ""
                                    text: t("Time left", "الوقت المتبقي") + ": " + timeUntilNextPrayer
                                    color: "#C8EEF0"
                                }
                            }
                        }

                        Repeater {
                            model: ["Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"]
                            delegate: PrayerTimeRow {
                                prayerName: root.prayerName(modelData)
                                prayerTime: root.to12HourTime(root.displayPrayerTimes[modelData])
                                active: root.activePrayer === modelData
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true

                            Button {
                                text: t("Test Adhan", "اختبار الأذان")
                                onClicked: {
                                    playAdhanAudio("Fajr")
                                }
                            }

                            Button {
                                text: t("Play Daily Verse", "تشغيل آية اليوم")
                                onClicked: playSpecificVerse(currentSurahNumber, currentAyahNumber)
                            }

                            Item { Layout.fillWidth: true }

                            Label {
                                text: t("Last update", "آخر تحديث") + ": " + lastUpdateText
                                color: "#A3C8CD"
                            }
                        }
                    }
                }
            }

            Item {
                ScrollView {
                    anchors.fill: parent
                    contentWidth: availableWidth

                    ColumnLayout {
                        width: parent.width - 28
                        x: 14
                        y: 14
                        spacing: 10

                        RowLayout {
                            Layout.fillWidth: true

                            Label { text: t("Reciter", "القارئ"); color: "#EAF7F6" }

                            ComboBox {
                                id: reciterCombo
                                Layout.fillWidth: true
                                model: isArabicUi ? reciterNamesAr : reciterNamesEn
                                currentIndex: settings.quranReciterIndex
                                onActivated: {
                                    settings.quranReciterIndex = currentIndex
                                    fetchDailyVerse()
                                }
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true

                            ComboBox {
                                id: surahCombo
                                Layout.fillWidth: true
                                model: root.surahData.map(function(s, index) {
                                    const surahNum = index + 1
                                    return isArabicUi ? (surahNum + ". " + s[1]) : (surahNum + ". " + s[0])
                                })
                                currentIndex: Math.max(0, currentSurahNumber - 1)
                            }

                            SpinBox {
                                id: ayahSpin
                                from: 1
                                to: {
                                    const idx = Math.max(0, surahCombo.currentIndex)
                                    return root.surahData[idx][2]
                                }
                                value: Math.max(1, currentAyahNumber)
                            }

                            Button {
                                text: t("Play", "تشغيل")
                                onClicked: playSpecificVerse(surahCombo.currentIndex + 1, ayahSpin.value)
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true

                            Button {
                                text: versePlayer.playbackState === MediaPlayer.PlayingState ? t("Pause", "إيقاف مؤقت") : t("Resume", "استئناف")
                                onClicked: {
                                    if (versePlayer.playbackState === MediaPlayer.PlayingState) {
                                        versePlayer.pause()
                                    } else {
                                        versePlayer.play()
                                    }
                                }
                            }

                            Slider {
                                Layout.fillWidth: true
                                from: 0
                                to: versePlayer.duration > 0 ? versePlayer.duration : 1
                                value: versePlayer.position
                                onMoved: versePlayer.position = value
                            }

                            Label {
                                text: Math.round(settings.quranVolume * 100) + "%"
                                color: "#C8EEF0"
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            Label { text: t("Quran Volume", "مستوى صوت القرآن"); color: "#EAF7F6" }
                            Slider {
                                Layout.fillWidth: true
                                from: 0.0
                                to: 1.0
                                stepSize: 0.05
                                value: settings.quranVolume
                                onMoved: settings.quranVolume = value
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            radius: 12
                            color: "#13283A"
                            border.color: "#1F3F55"

                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 12
                                spacing: 8

                                Label {
                                    Layout.fillWidth: true
                                    text: dailyVerseArabic
                                    color: "#F7F9E6"
                                    wrapMode: Text.WordWrap
                                    font.pixelSize: 24
                                    horizontalAlignment: Text.AlignHCenter
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: dailyVerseTranslation
                                    color: "#EAF7F6"
                                    wrapMode: Text.WordWrap
                                    horizontalAlignment: Text.AlignHCenter
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: dailyVerseReference
                                    color: "#A3C8CD"
                                    wrapMode: Text.WordWrap
                                    horizontalAlignment: Text.AlignHCenter
                                }
                            }
                        }
                    }
                }
            }

            Item {
                ScrollView {
                    anchors.fill: parent
                    contentWidth: availableWidth

                    ColumnLayout {
                        width: parent.width - 28
                        x: 14
                        y: 14
                        spacing: 12

                        GroupBox {
                            Layout.fillWidth: true
                            title: t("Language & Time", "اللغة والوقت")

                            GridLayout {
                                anchors.fill: parent
                                anchors.margins: 10
                                columns: 2
                                columnSpacing: 10

                                Label { text: t("Language", "اللغة") }
                                ComboBox {
                                    model: [t("System default", "لغة النظام"), "English", "العربية"]
                                    currentIndex: settings.languageMode
                                    onActivated: {
                                        settings.languageMode = currentIndex
                                        processRawTimesAndApplyOffsets()
                                    }
                                }

                                Label { text: t("Time format", "صيغة الوقت") }
                                CheckBox {
                                    text: t("Use 12-hour format", "استخدام صيغة 12 ساعة")
                                    checked: settings.hourFormat
                                    onToggled: {
                                        settings.hourFormat = checked
                                        processRawTimesAndApplyOffsets()
                                    }
                                }

                                Label { text: t("Hijri offset", "إزاحة التاريخ الهجري") }
                                SpinBox {
                                    from: -5
                                    to: 5
                                    value: settings.hijriOffset
                                    onValueModified: {
                                        settings.hijriOffset = value
                                        fetchTimes()
                                    }
                                }
                            }
                        }

                        GroupBox {
                            Layout.fillWidth: true
                            title: t("Location", "الموقع")

                            GridLayout {
                                anchors.fill: parent
                                anchors.margins: 10
                                columns: 2
                                columnSpacing: 10

                                Label { text: t("Use coordinates", "استخدام الإحداثيات") }
                                CheckBox {
                                    checked: settings.useCoordinates
                                    onToggled: settings.useCoordinates = checked
                                }

                                Label { text: t("City", "المدينة") }
                                TextField {
                                    enabled: !settings.useCoordinates
                                    text: settings.city
                                    onEditingFinished: settings.city = text
                                }

                                Label { text: t("Country", "الدولة") }
                                TextField {
                                    enabled: !settings.useCoordinates
                                    text: settings.country
                                    onEditingFinished: settings.country = text
                                }

                                Label { text: t("Latitude", "خط العرض") }
                                TextField {
                                    enabled: settings.useCoordinates
                                    text: settings.latitude
                                    onEditingFinished: settings.latitude = text
                                }

                                Label { text: t("Longitude", "خط الطول") }
                                TextField {
                                    enabled: settings.useCoordinates
                                    text: settings.longitude
                                    onEditingFinished: settings.longitude = text
                                }

                                Label { text: t("Calculation method", "طريقة الحساب") }
                                ComboBox {
                                    model: methodNames
                                    currentIndex: settings.method
                                    onActivated: settings.method = currentIndex
                                }

                                Label { text: t("Juristic school", "المذهب الفقهي") }
                                ComboBox {
                                    model: [t("Shafi", "شافعي"), t("Hanafi", "حنفي")]
                                    currentIndex: settings.school
                                    onActivated: settings.school = currentIndex
                                }

                                Item { }
                                Button {
                                    text: t("Apply & refresh", "تطبيق وتحديث")
                                    onClicked: fetchTimes()
                                }
                            }
                        }

                        GroupBox {
                            Layout.fillWidth: true
                            title: t("Prayer Offsets (minutes)", "تعديلات الدقائق")

                            GridLayout {
                                anchors.fill: parent
                                anchors.margins: 10
                                columns: 4
                                columnSpacing: 10

                                Label { text: t("Fajr", "الفجر") }
                                SpinBox { value: settings.fajrOffsetMinutes; from: -60; to: 60; onValueModified: { settings.fajrOffsetMinutes = value; processRawTimesAndApplyOffsets() } }
                                Label { text: t("Sunrise", "الشروق") }
                                SpinBox { value: settings.sunriseOffsetMinutes; from: -60; to: 60; onValueModified: { settings.sunriseOffsetMinutes = value; processRawTimesAndApplyOffsets() } }

                                Label { text: t("Dhuhr", "الظهر") }
                                SpinBox { value: settings.dhuhrOffsetMinutes; from: -60; to: 60; onValueModified: { settings.dhuhrOffsetMinutes = value; processRawTimesAndApplyOffsets() } }
                                Label { text: t("Asr", "العصر") }
                                SpinBox { value: settings.asrOffsetMinutes; from: -60; to: 60; onValueModified: { settings.asrOffsetMinutes = value; processRawTimesAndApplyOffsets() } }

                                Label { text: t("Maghrib", "المغرب") }
                                SpinBox { value: settings.maghribOffsetMinutes; from: -60; to: 60; onValueModified: { settings.maghribOffsetMinutes = value; processRawTimesAndApplyOffsets() } }
                                Label { text: t("Isha", "العشاء") }
                                SpinBox { value: settings.ishaOffsetMinutes; from: -60; to: 60; onValueModified: { settings.ishaOffsetMinutes = value; processRawTimesAndApplyOffsets() } }
                            }
                        }

                        GroupBox {
                            Layout.fillWidth: true
                            title: t("Adhan & Audio", "الأذان والصوت")

                            GridLayout {
                                anchors.fill: parent
                                anchors.margins: 10
                                columns: 2
                                columnSpacing: 10

                                Label { text: t("Notifications", "التنبيهات") }
                                CheckBox {
                                    text: t("Enable prayer notifications", "تفعيل تنبيهات الصلاة")
                                    checked: settings.notifications
                                    onToggled: settings.notifications = checked
                                }

                                Label { text: t("Adhan mode", "وضع الأذان") }
                                ComboBox {
                                    model: [t("No Adhan", "بدون أذان"), t("Full", "كامل"), t("Short (40s)", "قصير (40ث)"), t("Very short (17s)", "قصير جداً (17ث)")]
                                    currentIndex: settings.adhanPlaybackMode
                                    onActivated: settings.adhanPlaybackMode = currentIndex
                                }

                                Label { text: t("Adhan volume", "مستوى صوت الأذان") }
                                Slider {
                                    from: 0.0
                                    to: 1.0
                                    stepSize: 0.05
                                    value: settings.adhanVolume
                                    onMoved: settings.adhanVolume = value
                                }

                                Label { text: t("Custom adhan file", "ملف أذان مخصص") }
                                TextField {
                                    text: settings.adhanAudioPath
                                    placeholderText: t("Leave empty to use built-in audio", "اتركه فارغاً لاستخدام الصوت المدمج")
                                    onEditingFinished: settings.adhanAudioPath = text
                                }

                                Label { text: t("Play Adhan For", "تشغيل الأذان لـ") }
                                ColumnLayout {
                                    CheckBox { text: prayerName("Fajr"); checked: settings.playAdhanForFajr; onToggled: settings.playAdhanForFajr = checked }
                                    CheckBox { text: prayerName("Dhuhr"); checked: settings.playAdhanForDhuhr; onToggled: settings.playAdhanForDhuhr = checked }
                                    CheckBox { text: prayerName("Asr"); checked: settings.playAdhanForAsr; onToggled: settings.playAdhanForAsr = checked }
                                    CheckBox { text: prayerName("Maghrib"); checked: settings.playAdhanForMaghrib; onToggled: settings.playAdhanForMaghrib = checked }
                                    CheckBox { text: prayerName("Isha"); checked: settings.playAdhanForIsha; onToggled: settings.playAdhanForIsha = checked }
                                }
                            }
                        }

                        GroupBox {
                            Layout.fillWidth: true
                            title: t("About", "حول")

                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 10
                                spacing: 6

                                Label { text: root.title + " " + appVersion }
                                Label { text: t("Author", "المطور") + ": " + authorName }
                                Label { text: t("Email", "البريد") + ": " + authorEmail }
                                Label { text: "https://github.com/lnfiniware/al-muslim-for-Linux" }
                            }
                        }
                    }
                }
            }
        }
    }

    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: statusMessage === "" ? 0 : 34
        color: "#205D72"
        opacity: statusMessage === "" ? 0 : 0.94

        Behavior on height { NumberAnimation { duration: 150 } }
        Behavior on opacity { NumberAnimation { duration: 150 } }

        Label {
            anchors.centerIn: parent
            text: statusMessage
            color: "white"
            elide: Text.ElideRight
            width: parent.width - 20
            horizontalAlignment: Text.AlignHCenter
        }
    }
}
