# al-muslim for Linux (Desktop App)

Standalone Qt6 application for `al-muslim`, built to complement the KDE Plasma widget.

## Version

`1.0v`

## Build

```bash
cmake -S app -B build-app
cmake --build build-app -j
```

## Run

```bash
./build-app/al-muslim
```

## Install (optional)

```bash
cmake --install build-app
```

This installs:
- `al-muslim` binary to `bin/`
- desktop launcher to `share/applications/al-muslim.desktop`
